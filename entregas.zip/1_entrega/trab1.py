from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer 

#Criamos o ChatBot chamado Linguagens
chatbot = ChatBot('Linguagens')

#Criamos um "treinador"
trainer = ListTrainer(chatbot)

conversa = ['C++', 'Bjarne Stroustrup em 1983',
'Javascript','Brendan Eich em 1995',
'Python', 'Guido van Rossum em 1991',
'C#', 'Anders Hejlsberg em 1999',
'PHP', 'Rasmus Lerdorf em 1994',
'Swift', 'Chris Lattner em 2010',
'Ruby', ' Yukihiro Matsumoto em 1995',
'Pascal', 'Niklaus Wirth em 1972',
'R', 'Ross Ihaka e Robert Gentleman em 1993',
'Delphi', 'Borland em 1995',
'Dart', 'Lars Bak e Kasper Lund em 2011',

]

#Executamos o treinamento com o conjunto de palavras/sentenças
trainer.train(conversa)

#Laço de repetições para a conversa acontecer
while True:
    #Solicita uma entrada de dados para o usuário 
    pergunta = input("Digite uma linguagem de programação para saber o criador e seu ano de lançamento: ")
    #Busca uma resposta
    resposta = chatbot.get_response(pergunta)

    #Se o grau de confiança do  for inferior a 0.5, informa que não sabe o que responder 
    if float(resposta.confidence) > 0.5:
        print('Resposta: ', resposta)
    else:
        print('Me desculpe! Não tenho a informação para essa linguagem :/')