import sqlite3

# conecta ao banco de dados
conn = sqlite3.connect('locadora.db')

conn.execute('''CREATE TABLE filmes
             (id INTEGER PRIMARY KEY,
              numero TEXT,
              titulo TEXT,
              genero TEXT);''')


conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("1", "O Senhor dos Anéis", "Aventura"))
conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("2", "O Dilema das Redes", "Documentário"))
conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("3", "Top Gun: Maverick", "Ação"))
conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("4", "Os salafrários", "Comédia"))
conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("5", "A Órfã", "Terror"))
conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("6", "O Silêncio dos Inocentes", "Filme policial"))
conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("7", "A Vida é Bela", "Drama"))
conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("8", "Rio, eu te amo", "Musical"))
conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("1", "O Mágico de OZ", "Aventura"))
conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("5", "O Exorcista", "Terror"))
conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("9", "Garota Exemplar", "Mistério"))
conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("5", "Premonição", "Terror"))
conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("10", "O Mágico de OZ", "Ficção científica"))
conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("6", "Seven: Os Sete Crimes Capitais", "Filme policial"))
conn.execute("INSERT INTO filmes (numero, titulo, genero) VALUES (?,?,?)", ("9", "O Código Da Vinci", "Mistério"))


# confirma a inserção
conn.commit()
print("Esses são alguns dos gêneros disponíveis:")
print("[1] Aventura")
print("[2] Documentário")
print("[3] Ação")
print("[4] Comédia")
print("[5] Terror")
print("[6] Filme policial")
print("[7] Drama")
print("[8] Musical")
print("[9] Mistério")
print("[10] Ficção científica")
# obtém o gênero preferido do usuário
numero = input("Qual é o número do gênero preferido? ")

# escreve a consulta para obter os filmes do gênero escolhido
cur = conn.cursor()

cur.execute("SELECT titulo FROM filmes WHERE numero=?", (numero,))

# obtém os resultados da consulta e os exibe na tela
resultados = cur.fetchall()
if len(resultados) == 0:
    print("Não foram encontrados filmes do gênero escolhido.")
else:
    print("Filme(s) do gênero escolhido:")
    for filme in resultados:
        print(filme[0])

# fecha a conexão com o banco de dados
conn.close()
