from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer 

#Criamos o ChatBot chamado Linguagens
chatbot = ChatBot('Linguagens')

#Criamos um "treinador"
trainer = ListTrainer(chatbot)

conversa = ['Brasil', 'Brasília',
'Bélgica','Bruxelas',
'Bolivia', 'Sucre',
'Chile', 'Santiago',
'Itália', 'Roma',
'Japão', 'Tóqui',
'Argentina', 'Buenos Aires',
'Uruguai', 'Montevideu',
'Portugal', 'Lisboa',
'Espanha', 'Madrid',
'Estados Unidos', 'Washington',
'França', 'Paris',
'Grécia', 'Atenas',
'China', 'Pequim',
'Colômbia', 'Bogotá',
'Egito', 'Cairo',
]

#Executamos o treinamento com o conjunto de palavras/sentenças
trainer.train(conversa)

#Laço de repetições para a conversa acontecer
while True:
    #Solicita uma entrada de dados para o usuário 
    pergunta = input("Digite um país para saber sua capital: ")
    #Busca uma resposta
    resposta = chatbot.get_response(pergunta)

    #Se o grau de confiança do  for inferior a 0.5, informa que não sabe o que responder 
    if float(resposta.confidence) > 0.5:
        print('Resposta: ', resposta)
    else:
        print('Me desculpe! Não tenho a informação para esse país :/')